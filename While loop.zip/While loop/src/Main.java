
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        /*int num=100;
        int i=1;
        int sum=0;
        while(i<=num){
           sum=sum+i;
            i++;
        }
        System.out.println("The summation of 1 to 100 is:"+sum);*/
        // Do while Demo
        int num=10;
        int i=1;
        int sum=0;
        do{sum=sum+i;

            i++;
        }
        while (i<=num);
        System.out.println("The summation of 1 to 10 is:"+sum);
    }
}